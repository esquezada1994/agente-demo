"""SDK de telemetría de gobierno para soluciones de IA.

Registra el RECORRIDO de cada solicitud (entrada → recuperación → modelo →
herramientas → validación → respuesta) como trazas OpenTelemetry estándar y
las envía a la plataforma de gobierno.

Garantía de diseño: el SDK no tiene ningún parámetro para enviar contenido
(prompts, documentos, respuestas). Solo registra hechos medibles: tokens,
latencia, puntajes de búsqueda, errores, resultado y categoría de una
violación. Así la minimización de datos no depende de la disciplina de quien
lo usa.

Uso mínimo::

    import plataforma_sdk as gov

    gov.init(endpoint="https://api.ejemplo.com", api_key="gk_...", solution="cobranzas-whatsapp")

    with gov.request() as req:
        with gov.retrieval(source="vector://politicas") as r:
            docs = buscar(pregunta)
            r.record(scores=[d.score for d in docs])
        with gov.model_call("gpt-4.1-mini") as m:
            respuesta = llamar_modelo(...)
            m.record(input_tokens=..., output_tokens=...)
        req.outcome("resolved")

Si la solución ya usa OpenLLMetry u OpenInference, no hace falta este SDK:
basta con apuntar su exportador OTLP a la plataforma. Este SDK agrega lo que
esas herramientas no traen: etapa, fuente, puntaje de búsqueda, resultado y
validación.

Además de las trazas (REST, ver platform.py):

    gov.publish_manifest({...})                     # qué es la solución
    gov.value("revenue_recovered", amount=320.50)   # qué produjo
    gov.feedback(trace_id, -1)                      # cómo la valoró el usuario
"""

from plataforma_sdk.client import (
    Model,
    Request,
    Retrieval,
    Tool,
    Validation,
    current_trace_id,
    init,
    model_call,
    request,
    retrieval,
    shutdown,
    tool,
    validation,
)
from plataforma_sdk.platform import (
    Enrollment,
    PlatformError,
    enroll,
    feedback,
    flush,
    publish_manifest,
    set_synchronous,
    value,
)

__all__ = [
    "Enrollment",
    "Model",
    "PlatformError",
    "Request",
    "Retrieval",
    "Tool",
    "Validation",
    "current_trace_id",
    "enroll",
    "feedback",
    "flush",
    "init",
    "model_call",
    "publish_manifest",
    "request",
    "retrieval",
    "set_synchronous",
    "shutdown",
    "tool",
    "validation",
    "value",
]
