"""Implementación del SDK sobre OpenTelemetry."""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from datetime import datetime
from typing import Any

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.trace import Span, Status, StatusCode

SCOPE = "plataforma_sdk"
OUTCOMES = ("resolved", "escalated", "abandoned")

_provider: TracerProvider | None = None
_tracer: trace.Tracer | None = None
# Destino configurado en init(); lo usan también manifest, value y feedback.
_config: dict[str, str] = {}


def init(
    *,
    solution: str,
    endpoint: str | None = None,
    api_key: str | None = None,
    environment: str | None = None,
    version: str | None = None,
    processor: SpanProcessor | None = None,
    tracer_provider: TracerProvider | None = None,
) -> TracerProvider:
    """Configura el envío de trazas. Llamar una vez al iniciar la solución.

    - solution: la clave de telemetría registrada en la plataforma
      ("cobranzas-whatsapp"). Viaja como `service.name`.
    - endpoint y api_key: URL de la API de la plataforma y llave de ingesta.
    - version: versión publicada de la solución (la del manifiesto). Permite
      cruzar el antes y el después de una recomendación con un cambio.
    - processor: para pruebas o para enviar a otro destino (opcional).
    - tracer_provider: si la solución ya configuró OpenTelemetry, se reutiliza
      y solo se agrega el exportador de la plataforma.
    """
    global _provider, _tracer
    if tracer_provider is None:
        attributes: dict[str, Any] = {"service.name": solution, "gov.solution.key": solution}
        if environment:
            attributes["deployment.environment"] = environment
        if version:
            attributes["service.version"] = version
            attributes["gov.solution.version"] = version
        tracer_provider = TracerProvider(resource=Resource.create(attributes))
    if processor is None:
        if not endpoint or not api_key:
            raise ValueError("Se requieren endpoint y api_key (o un processor propio)")
        exporter = OTLPSpanExporter(
            endpoint=endpoint.rstrip("/") + "/v1/traces",
            headers={"authorization": f"Bearer {api_key}"},
        )
        processor = BatchSpanProcessor(exporter)
    tracer_provider.add_span_processor(processor)
    _config.clear()
    _config["solution"] = solution
    if endpoint and api_key:
        _config["endpoint"] = endpoint.rstrip("/")
        _config["api_key"] = api_key
    _provider = tracer_provider
    _tracer = tracer_provider.get_tracer(SCOPE)
    return tracer_provider


def shutdown() -> None:
    """Envía lo pendiente y cierra. Llamar al terminar el proceso."""
    from plataforma_sdk import platform

    platform.flush()
    if _provider is not None:
        _provider.shutdown()


def config() -> dict[str, str]:
    """Destino configurado (solución, endpoint y llave), para las llamadas REST."""
    return dict(_config)


def current_trace_id() -> str | None:
    """Id (hexadecimal) de la traza en curso, o None fuera de una solicitud.

    Sirve para ligar después una valoración o un evento de valor a la
    solicitud que lo produjo."""
    context = trace.get_current_span().get_span_context()
    return format(context.trace_id, "032x") if context.is_valid else None


def _get_tracer() -> trace.Tracer:
    if _tracer is None:
        raise RuntimeError("Llama a plataforma_sdk.init(...) antes de registrar trazas")
    return _tracer


class _Stage:
    def __init__(self, span: Span) -> None:
        self.span = span

    def error(self, kind: str = "error") -> None:
        """Marca la etapa como fallida. `kind` es una categoría, no un mensaje."""
        self.span.set_status(Status(StatusCode.ERROR))
        self.span.set_attribute("error.type", kind[:60])


class Request(_Stage):
    @property
    def trace_id(self) -> str:
        """Id de la traza de esta solicitud. Guardarlo para valorarla después."""
        return format(self.span.get_span_context().trace_id, "032x")

    def outcome(self, value: str) -> None:
        """Resultado de la solicitud: resolved, escalated (a una persona) o abandoned."""
        if value not in OUTCOMES:
            raise ValueError(f"outcome debe ser uno de {OUTCOMES}")
        self.span.set_attribute("gov.outcome", value)

    def feedback(self, value: int) -> None:
        """Valoración del usuario: 1 positiva, -1 negativa."""
        self.span.set_attribute("gov.feedback", 1 if value > 0 else -1)


class Retrieval(_Stage):
    def record(self, *, scores: Sequence[float] = (), documents: int | None = None) -> None:
        """Puntajes de similitud de lo recuperado (0 a 1). Nunca el contenido."""
        self.span.set_attribute(
            "gov.retrieval.documents", documents if documents is not None else len(scores)
        )
        if scores:
            self.span.set_attribute("gov.retrieval.top_score", float(max(scores)))


class Model(_Stage):
    def record(
        self,
        *,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cache_read_tokens: int = 0,
        response_model: str | None = None,
    ) -> None:
        self.span.set_attribute("gen_ai.usage.input_tokens", int(input_tokens))
        self.span.set_attribute("gen_ai.usage.output_tokens", int(output_tokens))
        if cache_read_tokens:
            self.span.set_attribute("gen_ai.usage.cache_read.input_tokens", int(cache_read_tokens))
        if response_model:
            self.span.set_attribute("gen_ai.response.model", response_model)


class Tool(_Stage):
    pass


class Validation(_Stage):
    def violation(self, category: str) -> None:
        """Registra una violación (personal_data, hallucination, off_topic…). Solo la categoría."""
        self.span.set_attribute("gov.validation.violation", category[:60])


@contextmanager
def _span(
    name: str, stage: str, attributes: dict[str, Any], wrapper: type[_Stage]
) -> Iterator[Any]:
    with _get_tracer().start_as_current_span(
        name, attributes={"gov.stage": stage, **attributes}
    ) as span:
        handle = wrapper(span)
        try:
            yield handle
        except Exception as exc:
            handle.error(type(exc).__name__)
            raise


@contextmanager
def request(name: str = "request", *, channel: str | None = None) -> Iterator[Request]:
    """Una solicitud completa (traza raíz)."""
    attributes = {"gov.channel": channel} if channel else {}
    with _span(name, "input", attributes, Request) as handle:
        yield handle


@contextmanager
def retrieval(
    *,
    source: str,
    source_name: str | None = None,
    source_kind: str | None = None,
    source_updated_at: datetime | None = None,
) -> Iterator[Retrieval]:
    """Búsqueda en una fuente. `source` es el identificador de la fuente en la
    plataforma (el mismo del catálogo). Si la fuente no existe, la plataforma
    la registra como detectada."""
    attributes: dict[str, Any] = {"gov.data_source.id": source, "gen_ai.data_source.id": source}
    if source_name:
        attributes["gov.data_source.name"] = source_name
    if source_kind:
        attributes["gov.data_source.kind"] = source_kind
    if source_updated_at:
        attributes["gov.data_source.updated_at"] = source_updated_at.isoformat()
    with _span("retrieval", "retrieval", attributes, Retrieval) as handle:
        yield handle


@contextmanager
def model_call(model: str, *, operation: str = "chat") -> Iterator[Model]:
    """Llamada a un modelo (convenciones GenAI de OpenTelemetry)."""
    attributes = {"gen_ai.operation.name": operation, "gen_ai.request.model": model}
    with _span(f"{operation} {model}", "model", attributes, Model) as handle:
        yield handle


@contextmanager
def tool(name: str, *, source: str | None = None) -> Iterator[Tool]:
    """Ejecución de una herramienta. `source`: la fuente que lee o escribe, si aplica."""
    attributes: dict[str, Any] = {"gen_ai.operation.name": "execute_tool", "gen_ai.tool.name": name}
    if source:
        attributes["gov.data_source.id"] = source
    with _span(f"execute_tool {name}", "tool", attributes, Tool) as handle:
        yield handle


@contextmanager
def validation(name: str = "validation") -> Iterator[Validation]:
    """Paso de validación (agente validador o guardarraíles)."""
    with _span(name, "validation", {}, Validation) as handle:
        yield handle
