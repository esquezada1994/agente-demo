"""Llamadas REST a la plataforma: enrolamiento, manifiesto, valor y valoración.

Las trazas viajan por OTLP (client.py). Esto cubre lo que no es una traza:

- enroll(): canjea un token de enrolamiento por una llave de ingesta.
- publish_manifest(): la solución declara qué es (gobierno como código).
- value(): un resultado de negocio ligado a la solicitud en curso.
- feedback(): la valoración del usuario, que llega después de la respuesta.

value() y feedback() se envían en segundo plano: la telemetría nunca debe
frenar ni romper la solución. Si la plataforma no responde, se registra un
aviso en el log y la solución sigue.
"""

from __future__ import annotations

import logging
import queue
import threading
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

import requests

from plataforma_sdk.client import config, current_trace_id

log = logging.getLogger("plataforma_sdk")

VALUE_KINDS = (
    "revenue_recovered",
    "revenue_promised",
    "revenue_generated",
    "cost_avoided",
    "time_saved",
    "task_completed",
)
MONEY_KINDS = VALUE_KINDS[:4]
TIMEOUT = 10


class PlatformError(RuntimeError):
    """La plataforma rechazó la petición (credenciales, alcance o datos)."""


@dataclass(frozen=True)
class Enrollment:
    api_key: str
    solution: str
    solution_name: str
    tenant: str


def _post(method: str, path: str, body: Mapping[str, Any], *, key: str | None = None) -> Any:
    cfg = config()
    endpoint = cfg.get("endpoint")
    api_key = key or cfg.get("api_key")
    if not endpoint or not api_key:
        raise RuntimeError("Llama a plataforma_sdk.init(endpoint=..., api_key=...) antes")
    response = requests.request(
        method,
        f"{endpoint}{path}",
        json=body,
        headers={"authorization": f"Bearer {api_key}"},
        timeout=TIMEOUT,
    )
    if response.status_code >= 400:
        # Solo el código de error: nunca el cuerpo enviado.
        code = response.json().get("code", "") if response.content else ""
        raise PlatformError(f"{response.status_code} {code}".strip())
    return response.json() if response.content else None


def enroll(endpoint: str, token: str, *, instance: str | None = None) -> Enrollment:
    """Canjea un token de enrolamiento (de un solo uso, generado en el portal)
    por una llave de ingesta limitada a la solución. Guardar la llave cifrada:
    no se puede volver a obtener."""
    response = requests.post(
        f"{endpoint.rstrip('/')}/v1/enroll",
        json={"token": token, "instance": instance},
        timeout=TIMEOUT,
    )
    if response.status_code >= 400:
        code = response.json().get("code", "") if response.content else ""
        raise PlatformError(f"{response.status_code} {code}".strip())
    data = response.json()
    return Enrollment(
        api_key=data["api_key"],
        solution=data["solution"],
        solution_name=data["solution_name"],
        tenant=data["tenant"],
    )


def publish_manifest(manifest: Mapping[str, Any]) -> dict[str, Any]:
    """Publica lo que la solución declara de sí misma: versión, modelos,
    fuentes, herramientas, datos personales, controles. Ver docs/telemetria.md.
    Es idempotente: publicar el mismo manifiesto no genera cambios."""
    body = {"solution": config().get("solution"), **manifest}
    result = _post("PUT", "/v1/manifest", body)
    return dict(result or {})


# --- En segundo plano ---------------------------------------------------------------


class _Sender:
    def __init__(self) -> None:
        self._queue: queue.Queue[tuple[str, dict[str, Any], str | None]] = queue.Queue(1000)
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def submit(self, path: str, body: dict[str, Any]) -> None:
        with self._lock:
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._run, daemon=True, name="gov-sender")
                self._thread.start()
        try:
            self._queue.put_nowait((path, body, config().get("api_key")))
        except queue.Full:
            log.warning("plataforma_sdk: cola llena, se descarta un evento")

    def _run(self) -> None:
        while True:
            path, body, key = self._queue.get()
            try:
                _post("POST", path, body, key=key)
            except Exception as exc:  # la telemetría nunca rompe la solución
                log.warning("plataforma_sdk: no se pudo enviar %s (%s)", path, exc)
            finally:
                self._queue.task_done()

    def flush(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            self._queue.join()


_sender = _Sender()
_sync = False


def set_synchronous(value: bool) -> None:
    """Envía value() y feedback() en el mismo hilo (para pruebas y scripts)."""
    global _sync
    _sync = value


def flush() -> None:
    """Espera a que se envíen los eventos pendientes."""
    _sender.flush()


def _send(path: str, body: dict[str, Any]) -> None:
    if _sync:
        _post("POST", path, body)
    else:
        _sender.submit(path, body)


def value(
    kind: str,
    *,
    amount: Decimal | float | None = None,
    currency: str | None = None,
    quantity: float | None = None,
    label: str | None = None,
    event_id: str | None = None,
    trace_id: str | None = None,
) -> str:
    """Registra un resultado de negocio y lo liga a la solicitud en curso.

    - Dinero (revenue_recovered, revenue_promised, revenue_generated,
      cost_avoided): `amount` y `currency`.
    - time_saved: `quantity` en horas. task_completed: `quantity` en tareas.
    - label: categoría corta ("promesa_pago"), nunca datos de una persona.
    - event_id: para no duplicar si se reenvía (por defecto, uno nuevo).

    Devuelve el event_id."""
    if kind not in VALUE_KINDS:
        raise ValueError(f"kind debe ser uno de {VALUE_KINDS}")
    if kind in MONEY_KINDS and amount is None:
        raise ValueError(f"{kind} requiere amount")
    if kind not in MONEY_KINDS and quantity is None:
        raise ValueError(f"{kind} requiere quantity")
    event_id = event_id or uuid.uuid4().hex
    event: dict[str, Any] = {
        "event_id": event_id,
        "kind": kind,
        "occurred_at": datetime.now(UTC).isoformat(),
        "trace_id": trace_id or current_trace_id(),
    }
    if amount is not None:
        event["amount"] = str(Decimal(str(amount)).quantize(Decimal("0.01")))
        event["currency"] = (currency or "USD").upper()
    if quantity is not None:
        event["quantity"] = float(quantity)
    if label:
        event["label"] = label[:60]
    _send("/v1/value", {"solution": config().get("solution"), "events": [event]})
    return event_id


def feedback(trace_id: str, value: int) -> None:
    """Valoración del usuario (1 o -1) de una solicitud ya respondida."""
    if value not in (1, -1):
        raise ValueError("value debe ser 1 o -1")
    _send(
        "/v1/feedback",
        {"solution": config().get("solution"), "trace_id": trace_id, "value": value},
    )
